from flask import Flask, render_template, request, jsonify
from tensorflow import keras
import numpy as np
import base64
import io
import os

from PIL import Image

import json
from json import JSONEncoder

import azureml.core
from azureml.core import Workspace
from azureml.core.model import Model



app = Flask(__name__)

def combineMask(masks):
    _output = np.empty((128, 256) + (1,))
    
    for x in range(0, masks.shape[0]):
        for y in range(0, masks.shape[1]):
                   _target = masks[x][y]
                   _output[x][y] = np.argmax(_target) 
    return _output

def preprocessPredictImg(img):
    img = img.resize((128, 256))
    image_matrix = np.expand_dims(img, 2)
    image_matrix = image_matrix.reshape((128, 256,3))

    X = np.empty((1, *(128, 256) + (3,)))
    X[0,] = image_matrix

    prediction = loaded_model.predict(X, batch_size=1)
    prediction_matrix = combineMask(prediction[0])

    return prediction_matrix

class NumpyArrayEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return JSONEncoder.default(self, obj)

ws = Workspace(subscription_id="cc471f5d-ca48-413b-bb86-0bb26a8001ac", resource_group="djawed", workspace_name="projet9")
model = Model(ws, 'model_base_plus')
model.download(target_dir='.', exist_ok=True)

loaded_model = keras.models.load_model('model_simple_unet_plus.h5')


image = keras.preprocessing.image.load_img('./website/static/test_img.png', target_size=(128, 256))
image_matrix = np.expand_dims(image, 2)
image_matrix = image_matrix.reshape((128,256,3))
X = np.empty((1, *(128,256) + (3,)))
X[0,] = image_matrix
prediction = loaded_model.predict(X, batch_size=1)
prediction_matrix = combineMask(prediction[0])
image = keras.preprocessing.image.array_to_img(
    prediction_matrix, data_format=None, scale=True, dtype=None,
    )
data = io.BytesIO()
image.save(data, "JPEG")
encoded_img_data = base64.b64encode(data.getvalue())


@app.route('/')
def index():

    return render_template('index.html',
                            username='Jaoid',
                            prediction=prediction,
                            image_data = encoded_img_data.decode('utf-8')
                            )

@app.route("/predict", methods=["POST"])
def process_image():
    
    file = request.files['image']
    img = Image.open(file.stream)

    img = preprocessPredictImg(img)

    json_string = json.dumps(img, cls=NumpyArrayEncoder)

    return jsonify({'msg': 'success', 'data': json_string})
